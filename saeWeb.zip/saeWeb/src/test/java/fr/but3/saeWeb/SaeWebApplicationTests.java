package fr.but3.saeWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaeWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
