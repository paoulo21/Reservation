package fr.but3.saeWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaeWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaeWebApplication.class, args);
	}

}
